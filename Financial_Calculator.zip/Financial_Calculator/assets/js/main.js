jQuery(document).ready(function () {
    alert('ss'); 
    jQuery('body.post-type-loan_calculator #postbox-container-2').html('');
});