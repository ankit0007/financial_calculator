<?php
define('PLUGINNAME', 'Loanplugin');
$PPATH=plugin_dir_url('Loanplugin').'/Loanplugin/';
